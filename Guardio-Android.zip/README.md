# Guardio (independent private build)

This is an independent private security-app project based on the uploaded MalwareZero Android source. The app is displayed as **Guardio** and uses original shield artwork with a lettermark; it is not the official Guardio app and is not affiliated with Guardio. It does not copy Guardio’s official icon or branding.

## Build with GitHub Actions

1. Upload the contents of this ZIP to a GitHub repository.
2. Open **Actions** and run **Build Guardio APK**, or push to `main`/`master`.
3. Download the `Guardio-debug-apk` artifact from the completed run.

## Current scope

The project includes its existing Android app scanner, user-selected file scanning, security checks, install monitoring, local threat history, and foreground live-protection service. Android does not provide one permission that lets an app inspect every email, every browser page, or other apps’ private data. Those capabilities require supported provider/browser integrations and explicit user-granted access.

The app is designed to be read-only by default. It does not silently delete files or uninstall apps; Android confirmation is required for destructive actions.
