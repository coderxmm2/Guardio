# Keep Room entities and DAOs
-keep class com.malwarezero.app.data.model.** { *; }
-keep class com.malwarezero.app.data.repository.** { *; }
